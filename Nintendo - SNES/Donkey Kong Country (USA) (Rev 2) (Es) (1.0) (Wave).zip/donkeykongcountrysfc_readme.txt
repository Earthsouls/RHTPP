Donkey Kong Country (Super Nintendo)
Traducción al Español v1.0 (11/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donkey Kong Country (U) (V1.2) [!].smc
MD5: 2e604bc12fb8f9467765c807c24877fa
SHA1: cd606e77ab2034438e06891cd2d067dad69b4d1a
CRC32: 762af827
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --