Do-Re-Mi Fantasy: Milon's Quest version 0.99  (6/15/00)
---------------------------------------------------------------------
by Gaijin Productions of CTC
Romhacker & Script Editor- recluse
Main Translator - Rom aka Unicorn
Early Translation - Musashi
Item Menu Translator - Faraday
Beta Testers - Farbanti & Balaraddak

About the patch
---------------
This patch fixed several text bugs.  I would like
to thank Jason Flythe for notifying me of a few
of the bugs this new version corrects.  Thanks!
(I would have corrected them long ago, but I have
not had steady access to a computer in monthes.)

About the game
--------------
Do-Re-Mi Fantasy: Milon's Quest is the sequal to
Milon's Secret Castle for the nes.  Yes, the cute
and very loveable Milon is back! This time with the
power of the snes against him!  This game is very fun,
yet easy for experienced gamers.  The rom is rather
rare, I understand, but please don't e-mail me asking
for it.  Now, enjoy the game you crudy human scum! 
(I'm just glad this project is behind me!)

What's done
-----------
-All item descriptions
-All dialogue
-All mini games

What's not done
---------------
-Any text that uses non-font graphics (They're compressed)

Things you should know
----------------------
If you should find any bugs, or errors
contact me via my e-mail danh@fidnet.com
Any feedback is welcome.

Controls
--------
Y-Shoots
B-Jumps
Hold Y & Direction Button-Runs
Hold Y & Stand Still-Charges Up Attack

Thanks goes to:
Rom/Unicorn, Musashi, Mad Hacker, Rom, Faraday, Farbanti, Hudson Soft, Jair (script extractor), Snowbro (tile layer), and Demi (rom hacking doc).

