***Donkey Kong Country Kremling's Revenge Remodel***

Hello guys,
 
I’m pleased to show you Donkey Kong Country Kremling's Revenge Remodel, which is a reboot from the original hack from Preposterify out in 2012. As I wasn’t able to speak with him (no one knows how to contact him), I decided to work on his hack with Simion32's DKC Resource Editor, and I modified quite a lot of stuff in it to make it even better for me :
 
- New graphics on almost every level (and it was the most difficult and time-consuming stuff),
- New design levels for some levels (Stop and go station for example). Water and ice levels are still really short because of the limits of DKC editors,
- Letter KONG now available in every level (except for water and ice levels…),
- New bonuses in almost every level (there are now the same number of bonuses as in the original DKC game, except for water and ice levels…),
- New difficulty game average : the difficulty of the entire game is now quite the same as in the original DKC game,
 
Hope you will enjoy it, and I will be pleased to read your comments. Don’t hesitate to signal glitches I wouldn't have seen, in order to correct them if I can.



Patch with LunarIPS the original unheadered US ROM of Donkey kong Country.

V1.1 - 11/09/2017