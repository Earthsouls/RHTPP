DKC Mania updated release -by Hankhill89 and RainbowSprinklez


1.introduction 

Welcome to the updated released build of this hack
The goal of this hack is to mix some new levels with some 
reimagined versions of old levels from the series past
I Hopefully made the game fairly balanced in difficulty
I aimed to make it as hard as DKC 2 was easy at world 1 
but fairly hard by the end the game should be playble all
the way to the end. 

 2. How to Patch 
Find a US V1.0 headerless version of the game
and use Beat or Flips to patch the .Bps file 


3. Distribution
-Do not share this hack without this readme
-Do not share the full ROM file of this only share it as a patch Bps, Ips, Ups etc.
-Do not make a reproduction cart of this hack
-DO not claim this hack as your own


4. Bugs
- In some jungle bonuses may have broken placement of bananas for some reason Dunno how to fix
-Some palette bugs may happen I worked on minimizing this but may still happen in some levels 
- Kong will not properly get in mine kart and walk in mid-air sometimes 

5.credits
Rainbow Sprinklez -for His involement in this hack he made and lot of nice tweaks and improvements
honestly he did most of the real work in this update big thanks :)

Simion 32 - for the DKC resource editor which makes editing levels a snap
Whoever made the orginal DK edit needed it for map importing as DKCRE doesnt import
Platium map files 

6. update 1.1 fixes
-Fixed blast barrels in level 4-1 to prevent a bug which may force a player to die 
due to the barrels not lining up second barrel no longer moves around so it should no longer be a problem
also made some blast barrels more visible now.
- Made a moved a set of bananas in 2-2 a bit forward

update 2.0 improvments and Fixes
-tweaked title cards with mine and Rainbowsrinklez on it now 
-RainbowSrinklez added Ice physics to level 6-3 as well a new palettes for level 3-4 and 6-3 in this hack
helped with making the animal buddy not dissapear upon exiting a bonus in 3-2 Big thanks :)
-redone layout in level 5-1 now it has better flow throughout
-Some enemies and levels have new colors in addition 2-p contest colors are now based on DKC2 for Diddy and DKC3 for DK
-Vertical Levels now have some edits done to them and have updated new names
-Very Gwanty and Really Gwanty take more hits to take down now hopefully they ain't total pushovers 
like in the vanilla DKC big thanks again to Rainbowsprinklez
-Lives are now infinite so no worries about getting a game over in addition the death sequence is removed  
in this hack credit once again to Rainbowsprinklez
-Jungle bonuses no longer have garbage bananas in them
-level 6-3 has new music

