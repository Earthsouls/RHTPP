
  _____  _  _______   _____           _  __ _     _   
 |  __ \| |/ / ____| |  __ \         (_)/ _(_)   | |  
 | |  | | ' / |      | |__) |_ _  ___ _| |_ _ ___| |_ 
 | |  | |  <| |      |  ___/ _` |/ __| |  _| / __| __|
 | |__| | . \ |____  | |  | (_| | (__| | | | \__ \ |_ 
 |_____/|_|\_\_____| |_|   \__,_|\___|_|_| |_|___/\__|
                                                      
                                                      

DKC Pacifist by RainbowSprinklez


1. Introduction
Welcome to the first released build of this hack. The goal of this hack is to harm as few enemies as possible. You are penalized by taking damage and ten seconds added to your timer are added if you harm an enemy. Each boss has been modified so you never have to deal damage to win. Lives have been completely removed from this. This was designed to be raced.
Added features:
- Quick death: on death, you instantly start the stage over from your last checkpoint
- Always exit: Start select has been globally enabled
- Harm counter: A counter has been added to the overworld counting enemies harmed
- Stage timer: A timer has been added to the overworld as well as in-stage. This timer is based on the game timer, so only in-stage time is counted 

1.001:
Welcome to the second released build of this hack. The goal of this hack is the same as above. I just made a few changes.
Changes include:
- Music restart: Music no longer restarts on death, allowing you to hear full tracks
- Animal Tokens/KONG Letters: Most animal tokens and letters were removed from this (some bonus prizes still award you with them though!)
- OIL drums are people too!: Destroying oil drums now damages you
- Ending: The ending to perils has been redone


2. How to Patch 
Find a US V1.0 headerless version of the game and use LunarIPS (acquired at https://www.romhacking.net/utilities/240/) to apply the IPS file

3. Distribution
-Do not share this hack without this readme
-Do not share the full ROM file of this, only share it as a patch Bps, Ips, Ups etc.
-Do not make a reproduction cart of this hack
-Do not claim this hack as your own

4. Bugs
-There is some serious lag in certain places. This is due to SNES limitations

5. Credits
Myself086-He made this possible, helping with general guidance. The biggest thing he contributed was his debugging emulator/assembler.
