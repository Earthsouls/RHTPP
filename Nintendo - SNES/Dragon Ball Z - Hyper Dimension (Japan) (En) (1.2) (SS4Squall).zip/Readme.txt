This patch was created by SS4Squall<ss4squall_99@yahoo.com><dbztrans.nethop.com>
First 3% done by Vincent<vincenttrans@hotmail.com> 

The Rules:

Do not distribute this patch without the other files included with it.
Do not alter this patch in any way.
Do not place this patch on a web page without my permission.
Do not attempt to sell this patch to anyone.
Do not try and claim credit for my patch.

