This hack was made by me, RainbowSprinklez, under the guidance of Myself086 (a real genius). The game only allows 5 y presses, in the bee boss. And they will automatically be 1 frame inputs, even if you hold y! Holding y does nothing for you.

Every entrance starts you with both Kongs. Bonuses too! The last stage was made easier because let's be real. Did you really want to go through that grey Krusha section with no Y? All the Krushas in the final level are now green. Green means DK could kill by stomping on their head, and Diddy bounces off of them.

This also does a few other things. For example, infinite lives are given. Also, quick deaths are now a thing. 

This is a fun race to try!

This requires an unheadered 1.0 U DKC ROM.